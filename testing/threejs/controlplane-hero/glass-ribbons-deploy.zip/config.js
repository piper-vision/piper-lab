// Tuning knobs for the glass-ribbon scene. Plain global so it can be edited
// without touching the module code.
window.CONFIG = {
  colors: {
    bright: 0x5ce5df,
    dark:   0x003732,
    mid:    0x007d6e,
  },

  background: {
    scale: 1.1,        // noise frequency across the view (lower = bigger blobs)
    speed: 0.05,       // how fast the gradients drift
    warp: 2.0,         // domain-warp strength (organic swirl amount)
    octaves: 3,        // fewer octaves = softer, less veiny
    brightAmount: 0.9, // how much of the light aqua shows through
    vignette: 0.5,     // darkening toward the edges (0 = none)
  },

  // Ribbon: one wide band of glass triangles running into the distance, flowing toward the camera.
  ribbon: {
    rows: 60,           // rows of triangles across the ribbon (its left-right width)
    edgeFadeStart: 0.3, // fraction of the half-width where the side rows start fading into the gradient (1 = hard edges)
    edgeFadePower: 1.6,
    fadeDepth: [7, 19],   // camera distance (world units) where the band starts / finishes fading into the background
    length: 40,         // world units the strip spans (runs from behind the camera to beyond the fade)
    segment: 0.55,      // base length of each triangle along the ribbon
    width: 0.28,        // height of each triangle row (total ribbon width = rows * width)
    extrude: 0.035,     // how thick each triangle prism is
    bevel: 0.014,       // bevel size (sub-pixel bevels alias badly; FXAA covers ~1px)
    gap: 0.008,         // seam between neighbouring triangles
    flowSpeed: 0.56,    // units/s the triangles travel toward the camera

    // Shape: one broad arch (rises then falls across the view) that slowly breathes, plus a faint secondary ripple.
    waveAmp: 1.1, waveFreq: 0.14, waveSpeed: 0.1, wavePhase: 1.2,
    waveDwell: 5.0,     // 1 = plain sine; higher = the surface lingers near its crest (close to camera) and dips briefly
    wave2Amp: 0.25, wave2Freq: 0.4, wave2Speed: 0.25,
    growth: 0.0,        // 0 = even amplitude; >0 makes the arch grow toward the right

    // Depth wobble and roll about the flow direction (the "ribbon" twist).
    depthAmp: 0.35, depthFreq: 0.15, depthSpeed: 0.15,
    twistAmp: 0.25, twistFreq: 0.18, twistSpeed: 0.2,

    drift: 0.3, driftSpeed: 0.12, // slow vertical wander of the whole ribbon

    // Placement of the whole band in the scene.
    tiltX: 0.1,         // radians about X: small positive lifts the far end so it sits near the horizon
    yaw: -1.5708,       // -90 deg: the band runs into the depth; local +x (flow) points at the camera
    position: [0, -2.2, 0],
  },

  // Triangles occasionally lift off the ribbon and settle back.
  breakaway: {
    enabled: false,
    interval: [1.5, 4.0], // seconds between bursts (random in range)
    count: [1, 5],        // triangles per burst (random in range, inclusive)
    stagger: 0.6,         // max random delay within a burst so they don't move in lockstep
    distance: [0.6, 1.1], // how far a triangle lifts along the ribbon normal (random in range)
    lateral: 0.2,         // sideways drift while away
    tilt: 0.25,           // radians of tilt while away
    outDuration: 1.6,     // seconds to leave
    holdDuration: [1.2, 3.0], // random hold range
    backDuration: 2.0,    // seconds to return
  },

  glass: {
    mode: 'fake',      // 'real' = physically-based transmission (expensive); 'fake' = plain transparency + reflections (looks near-identical on this flat band)
    fakeOpacity: 0.8,  // body opacity in fake mode (rows still fade toward the edges on top of this); higher = richer, less background bleed
    fakeTint: 0x021c19, // body colour in fake mode: very dark teal (darker = the shaped env lights read stronger against it)
    ior: 1.55,
    thickness: 0.6,    // ribbons are thin, so keep the simulated volume thin too
    dispersion: 9,     // chromatic split at the edges (safe to go high: only the gradient is refracted)
    roughness: 0.22,   // body roughness blurs the refraction; clearcoat keeps surface highlights sharp
    clearcoatRoughness: 0.2, // sharpness of surface glints. 0.04 let the directional lights clip into pure-white blobs; 0.2 keeps them as soft highlights
    transmissionScale: 0.5, // refraction buffer resolution multiplier (0.5 = quarter the pixels; the roughness blur hides it)
    iridescence: 0.7,
    envIntensity: 1.0,  // overall reflection strength
    washColor: [0.06, 0.14, 0.13], // linear HDR colour of the ambient env sphere: edge-free base sheen (too high = washed out / frosted)
    tint: 0xffffff,
    attenuation: 0xbff5f1, // colour the body takes on as light travels through it
    attenuationDistance: 3.5,
  },

  bloom: {
    threshold: 1.6,    // luminance (linear, pre-tonemap) above which pixels glow
    strength: 0.3,     // how much glow is added back
    passes: 3,         // blur iterations at half resolution (wider glow per pass)
  },

  motion: { paused: false },

  // Shadow underlay: a dark sheet that rides just beneath the glass so the gaps
  // and bevels read as shadowed grooves (light mode wants this; the approved
  // dark look keeps it off). Presets set colour / opacity via the panel.
  // Per-triangle variation (panel: Triangles > Facet tilt / Facet tint). Breaks
  // the coplanar sameness of neighbouring triangles so the surface has more
  // contrast. The approved dark look keeps both at 0.
  facets: {
    jitter: 0,          // max random tilt per triangle, degrees
    tint: 0,            // 0..1 how far each triangle's body colour may lean toward tintColor
    tintColor: '6f9fff',
  },

  // Light pulses: glowing streaks that travel along the grooves between the
  // triangles, near the camera only. Drawn on the shadow underlay, so they
  // need light mode's shadow sheet (or at least pulses.enabled) to be drawn.
  pulses: {
    enabled: false,
    count: 10,          // concurrent pulses (max 12)
    speed: 4,           // lattice units per second (a unit is ~0.28 world units)
    length: 10,         // tail length, lattice units
    width: 0.12,        // glow half-width across the groove, lattice units (~the groove + bevels; larger bleeds into the glass)
    intensity: 8,       // HDR brightness (values above the bloom threshold glow)
    color: 'dfeeff',
    near: [3, 10],      // camera distance where pulses are full / gone
    rowBand: 0.6,       // fraction of the band's width (centred) the along-flow pulses use
    diagonalShare: 0.5, // fraction of pulses that run across the band on the diagonals
  },

  underlay: {
    color: '3a4e78',
    opacity: 0,        // 0 = off (the sheet is not even drawn)
    offset: 0.004,     // distance below the prisms' top face, world units (kept tiny so the gaps line up with the sheet)
  },

  // PNG export (E / Shift+E / the export buttons): output size as a multiple of
  // the frame's css size. 4 = double the original 2x export; a full-screen
  // MacBook frame comes out around 6750 x 4300 px.
  export: {
    scale: 6,         // output = frame css size x this (a MacBook browser window -> ~9900 x 5500 px)
    supersample: 2,   // each tile is rendered at this x the output resolution and box-filtered down
    marginPx: 160,    // overlap between tiles, in render pixels, so bloom / DoF / FXAA never see a tile edge
  },

  // Single-triangle studio (key 1): one prism at the origin, drag to rotate,
  // wheel to zoom, E to export. It copies the centre row's material when
  // entered; `opacity` scales that body opacity (1 = same as the band).
  single: {
    opacity: 0.6,
    apex: 1.2,   // height of the middle point relative to the band's triangle (1 = identical)
  },

  // Cluster scene (key 2; R re-rolls while it is on): a random connected patch
  // of triangles assembles on the right of the frame, each one sliding in from
  // outside the frame with a random tilt.
  cluster: {
    shape: 'triangle',  // 'triangle' = one big triangle built from the small ones; 'blob' = random connected patch
    size: 6,            // rows in the big triangle (6 rows = 36 triangles)
    cells: 46,          // triangles in the blob shape
    columns: 16, rows: 9, // lattice the patch may grow inside (columns are half a segment wide)
    fill: 0.65,         // chance a frontier cell joins when picked (lower = more ragged outline)
    dist: 3.4,          // camera distance
    offsetX: 1.05, offsetY: 0.05, // composition centre in world units (camera looks at the origin)
    tiltX: 0.28, tiltY: -0.42, tiltZ: 0,  // radians: lean the patch toward the camera / turn it a little (drag to rotate in the scene, C copies the values)
    scale: 0.82,
    // Motion, all periodic in loop.period (15 s) so any 15 s window loops exactly:
    turns: { x: 0, y: 1, z: 0 },       // full rotations per loop about each axis (y: 1 = one slow spin every 15 s)
    wobble: { x: 0.25, y: 0, z: 0.15, cyclesX: 1, cyclesZ: 2 }, // extra rocking, radians, whole cycles per loop
    bob: { amp: 0.08, cycles: 2 },     // small triangles rise / fall along the normal: amplitude (world units), max cycles per loop
  },

  // "15 Second Loop" (panel button / L): the scene becomes exactly periodic so
  // the frame at `period` seconds matches the frame the loop started on.
  //  - flow: the triangle travel speed snaps to a whole number of triangle
  //    lengths per period (0.56 -> 0.55 units/s at 15 s), so the strip lands
  //    back on itself;
  //  - shape and background: their slow drifts are far too slow to complete a
  //    cycle in 15 s, so instead their clock swings sinusoidally around the
  //    start time (forward, then back, seamlessly). `swing` scales how far it
  //    wanders: 1 = the same speed as normal at the loop point.
  loop: { period: 15, swing: 1.0 },

  // Hover ripple: the triangle under the cursor and its neighbours lift along
  // the band's normal with a gaussian falloff, easing in and out so the wave
  // trails the pointer.
  hover: {
    enabled: false,    // off by default; H key or the panel toggles it
    radius: 0.35,      // falloff radius in world units (band rows are 0.28 apart): ~the hovered triangle + one ring of neighbours
    lift: 0.28,        // peak lift at the cursor, world units
    ease: 7,           // lift easing rate per second (higher = snappier, lower = more swell)
    follow: 18,        // how quickly the ripple centre glides after the cursor (per second)
    pickRadius: 0.6,   // outer cap (NDC) on the nearest-point search; the real hover test is cell-relative
  },

  // Directional lights (outside the env map). Their sharp clearcoat specular
  // shows as small glints on facets that happen to align; keep them modest and
  // palette-matched. Presets override these.
  sun: {
    key: { color: 'ffe0b0', intensity: 0.6 },
    rim: { color: '9fe8ff', intensity: 0.5 },
  },

  // Legibility fade behind the logo / H1 / bottom-left copy, rendered in the
  // final composite shader (float precision + dither = no banding, and it is
  // part of the canvas so stills/exports include it). Geometry from the
  // design's fade.svg: a blurred circle off the left edge at mid-height.
  fade: {
    enabled: true,
    color: '0C3838',   // hex, no '#'
    opacity: 0.73,     // James's tuned value
    size: 88,          // circle diameter as % of the frame width (svg was 127)
    x: 5,              // centre, % of frame width
    y: 55,             // centre, % of frame height (svg: 429 / 779)
    blur: 12.5,        // edge softness as % of the frame width (svg: 138px blur on 1035px)
  }, // freeze everything (ribbon flow, waves, twist, background drift); Space or the panel toggles it

  // Tilt-shift depth of field: sharp band around a horizontal focus line, blurring
  // progressively toward the bottom (near triangles) and top (far end).
  dof: {
    enabled: true,
    focus: 0.5,        // focus line as a fraction of screen height (0 = bottom, 1 = top)
    width: 0.08,       // half-height of the fully sharp band
    feather: 0.35,     // how far beyond the band the blur takes to reach full strength
    near: 1.0,         // blur strength below the focus line (0..1)
    far: 1.0,          // blur strength above the focus line (0..1)
    clampHighlights: 1.6, // cap HDR values before the DoF blur (1 = white); stops blurred speculars becoming glowing blobs. 0 = off
  },

  camera: { fov: 38, distance: 4.0, height: -0.6, lookAtY: -1.5 }, // height = camera y (band sits around y -2.2); lookAtY < 0 pitches the view down onto the band

  // "Randomize scene" (panel button / R). Each press draws `candidates` random
  // scenes inside these ranges, renders each at a low resolution, scores the
  // frame on composition, and keeps the best. Motion is frozen and the
  // legibility fade switched off for the result. Lights are scaled relative to
  // the look that was active before the first roll (so rolls never drift).
  randomize: {
    candidates: 12,
    evalPixelRatio: 0.35,   // render scale for the candidate renders (the winner is re-rendered at still quality)
    camera:   { distance: [2.5, 7], height: [-0.8, 2.0], lookAtY: [-3, 0.5], fov: [28, 55] },
    rotation: { x: [-10, 10], y: [-25, 25], z: [-8, 8] },   // degrees, added to the band's resting orientation
    ribbon:   { waveAmp: [0.6, 1.6], twistAmp: [0.1, 0.6] },
    lightScale: [0.5, 1.8],   // env light intensity multiplier range
    sunScale:   [0.4, 2.0],   // directional light multiplier range
    phase: { time: [0, 600], flow: [0, 60] },   // animation clock / travel distance to jump to
    minClearance: 0.7,        // reject candidates whose band comes closer than this to the camera (world units)
    // Scoring weights (each term is roughly 0..1 before weighting). Tune to taste.
    weights: {
      clipping: 3.0,   // penalty per % of pure-white pixels above 1%
      exposure: 2.0,   // penalty for mean brightness outside a comfortable range
      contrast: 1.5,   // reward for a healthy spread between dark body and sheen
      thirds:   2.5,   // penalty for the highlight sitting far from a rule-of-thirds intersection
      edge:     2.0,   // penalty for the highlight hugging the frame edge
      balance:  1.0,   // penalty for all the light mass on one side
      horizon:  1.5,   // reward when the top of the frame dissolves (band not filling the whole view)
      foreground: 1.5, // reward for near triangles at a good size (not a wall, not gravel)
    },
  },
  exposure: 1.05,

  // Performance. Render resolution is fixed: the device pixel ratio capped at
  // maxPixelRatio (adaptive step-down was removed at James's request).
  quality: {
    msaa: 4,             // MSAA samples on the HDR scene target (FXAA covers the rest)
    maxPixelRatio: 1.25, // cap on device pixel ratio. James measured on his MacBook: 1.25 = 70 fps / 13 ms and still looks good; 2 (full Retina) was too slow
    // Frozen frames (Space / panel Motion) render as stills at higher quality:
    stillSupersample: 3,   // native device pixel ratio x this, so a still always reaches the cap below (was 2; James saw jaggies on randomizer stills)
    stillPixelRatio: 3,    // still pixel ratio (3x = 9x the pixels of 1x, downscaled = clean bevel lines)
    stillMaxPixels: 24e6,  // cap on rendered pixels for a still (GPU memory guard; 3x on a full-screen MacBook is ~17 MP, so 3x holds up to ~2000x1330 css px)
  },
};
